import type { Metadata } from "next";
import { withMetadataValidation } from "@/lib/metadata-utils";

export const metadata: Metadata = withMetadataValidation({
  title: "Canada",
  description: "Immigration options",
  keywords: ['Canada', 'visa', 'immigration', 'study'],
  openGraph: {
    title: "Canada",
    description: "Immigration options",
    type: 'website',
    images: [
      {
        url: '/countries_hero/Canada.jpeg',
        width: 1200,
        height: 630,
        alt: 'Study and Immigration in Canada',
      }
    ],
  },
  twitter: {
    title: "Canada",
    description: "Immigration options",
    card: 'summary_large_image',
    images: [
      '/countries_hero/Canada.jpeg',
    ],
  }
});