import CanadaUniversityPage from "./university-page"
import { metadata } from "./metadata"

export default function CanadaPage() {
  return <CanadaUniversityPage />
}
