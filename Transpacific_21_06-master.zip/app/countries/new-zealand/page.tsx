import NewZealandUniversityPage from "./university-page"
import { metadata } from "./metadata"

export default function NewZealandPage() {
  return <NewZealandUniversityPage />
}
