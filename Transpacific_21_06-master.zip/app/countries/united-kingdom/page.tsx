import UKUniversityPage from "./university-page"
import { metadata } from "./metadata"

export default function UnitedKingdomPage() {
  return <UKUniversityPage />
}
