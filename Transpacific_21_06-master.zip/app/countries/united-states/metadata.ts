import type { Metadata } from "next";
import { withMetadataValidation } from "@/lib/metadata-utils";

export const metadata: Metadata = withMetadataValidation({
  title: "United States",
  description: "Immigration options",
  keywords: ['USA', 'visa', 'immigration', 'study'],
  openGraph: {
    title: "United States",
    description: "Immigration options",
    type: 'website',
    images: [
      {
        url: '/countries_hero/USA.jpeg',
        width: 1200,
        height: 630,
        alt: 'Study and Immigration in the United States',
      }
    ],
  },
  twitter: {
    title: "United States",
    description: "Immigration options",
    card: 'summary_large_image',
    images: [
      '/countries_hero/USA.jpeg',
    ],
  }
});