import UnitedStatesUniversityPage from "./university-page"
import { metadata } from "./metadata"

export default function UnitedStatesPage() {
  return <UnitedStatesUniversityPage />
}
