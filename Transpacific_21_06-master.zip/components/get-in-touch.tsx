export default function GetInTouch() {
  // This component intentionally returns null to remove it from the site
  return null
}
